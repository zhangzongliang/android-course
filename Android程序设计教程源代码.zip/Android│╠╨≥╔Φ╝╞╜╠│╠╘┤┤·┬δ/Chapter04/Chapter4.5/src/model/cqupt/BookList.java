package model.cqupt;

import java.util.ArrayList;

import db.cqupt.DBconnection;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class BookList extends ArrayList<Book> {

	private static final long serialVersionUID = 1L;

	private static BookList booklist = null;

	private BookList() {

	}

	public  static BookList getBookList() {
		if (booklist == null) {
			booklist = new BookList();
			DBconnection connection = new DBconnection();
			SQLiteDatabase db = connection.getConnection();
			Cursor cur = db.query("book", null, null, null, null, null, null);
			while (cur.moveToNext()) {
				int idNum = cur.getColumnIndex("id");
				int nameNum = cur.getColumnIndex("name");
				int priceNum = cur.getColumnIndex("price");
				String id = cur.getString(idNum);
				String name = cur.getString(nameNum);
				String price = cur.getString(priceNum);
				Book book = new Book(id, name, price);
				booklist.add(book);
				cur.moveToNext();
			}
			connection.close(db);
		}
		return booklist;

	}
	
	/**
	 * ����id
	 * 
	 * @param bookid
	 * @return
	 */
	private boolean checkId(String bookid) {
		for (int i = 0; i < booklist.size(); ++i) {
			Book book = booklist.get(i);
			String id = book.getId();
			if (id.equals(bookid)) {
				return true;
			}
		}
		return false;
	}

	/**
	 * �õ�ͼ��λ��
	 * 
	 * @param bookid
	 * @return
	 */
	private  int getIndex(String bookid) {
		int i = 0;
		for (; i < booklist.size(); ++i) {
			Book book = booklist.get(i);
			String id = book.getId();
			if (id.equals(bookid)) {
				break;
			}
		}
		return i;
	}

	/**
	 * ��������
	 * 
	 * @param name
	 * @return
	 */
	public  boolean checkName(String name) {
		for (int i = 0; i < booklist.size(); ++i) {
			Book book2 = booklist.get(i);
			if (book2.getName().equals(name)) {
				booklist.remove(i);
				return true;
			}
		}
		return false;
	}

	public boolean insert(Book book) {

		if (checkId(book.getId())) {
			return false;
		} else {
			booklist.add(book);
			String id = book.getId();
			String name = book.getName();
			String price = book.getPrice();
			DBconnection connection = new DBconnection();
			SQLiteDatabase db = connection.getConnection();
			String sql = "INSERT INTO book(id,name,price)" + "VALUES('" + id
					+ "','" + name + "','" + price + "')";
			db.execSQL(sql);
			db.close();
			return true;
		}
	}

	public  boolean delete(String name) {
		if (checkName(name)) {
			DBconnection connection = new DBconnection();
			SQLiteDatabase db = connection.getConnection();
			String sql = "DELETE FROM book WHERE name='" + name + "'";
			db.execSQL(sql);
			return true;
		} else {
			return false;
		}
	}

	public  boolean set(Book book) {
		if (checkId(book.getId())) {
			String id = book.getId();
			String name = book.getName();
			String price = book.getPrice();
			int index = getIndex(id);
			booklist.set(index, book);
			DBconnection connection = new DBconnection();
			SQLiteDatabase db = connection.getConnection();
			String sql = "UPDATE book SET name='" + name + "'," + "price='"
					+ price + "' WHERE id='" + id + "'";
			db.execSQL(sql);
			return true;
		} else {
			return false;
		}
	}


}
