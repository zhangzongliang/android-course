package control.cqupt;

import model.cqupt.Book;
import model.cqupt.BookList;

public class Controller {
	public boolean addBook(String id, String name, String price) {
		BookList booklist = BookList.getBookList();
		Book book = new Book(id, name, price);
		if (booklist.insert(book))
			return true;
		else
			return false;
	}

	public boolean deleteBook(String name) {
		BookList booklist = BookList.getBookList();
		if (booklist.delete(name))
			return true;
		else
			return false;
	}

	public boolean setBook(String id, String name, String price) {
		BookList booklist = BookList.getBookList();
		Book book = new Book(id, name, price);
		if (booklist.set(book))
			return true;
		else
			return false;
	}

	public BookList searchBook() {
		BookList booklist = BookList.getBookList();
		return booklist;

	}

}
