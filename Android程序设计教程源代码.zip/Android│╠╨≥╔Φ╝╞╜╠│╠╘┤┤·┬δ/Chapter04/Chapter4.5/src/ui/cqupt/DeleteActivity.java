package ui.cqupt;

import control.cqupt.Controller;
import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

public class DeleteActivity extends Activity {
	private EditText name;

	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.delete);
		name = (EditText) findViewById(R.id.dname);
		Button delete = (Button) findViewById(R.id.d_delete);
		delete.setOnClickListener(new ButtonListener());
	}

	class ButtonListener implements OnClickListener {

		public void onClick(View v) {
			String bookname = name.getText().toString();
			Controller control = new Controller();
			if (bookname.equals("")) {
				new Builder(DeleteActivity.this).setMessage("ͼ��������Ϊ��").show();
			} else {
				if (control.deleteBook(bookname)) {
					name.setText("");
					buildDialog();
				} else {
					new Builder(DeleteActivity.this).setMessage("û�д�ͼ��").show();
				}
			}
		}

		private void buildDialog() {
			Builder builder = new Builder(DeleteActivity.this);
			builder.setTitle("ɾ���ɹ�,�Ƿ����ɾ��ͼ��");
			builder.setNegativeButton("������ҳ",
					new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog,
								int whichButton) {
							finish();
						}

					});
			builder.setPositiveButton("����ɾ��", null);
			builder.show();
		}
	}
}