package android.preference;
import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;

public class preference extends Activity {
	/** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
}


       protected void onstop(){
            //��ȡSharedPreferences����
           
       SharedPreferences sp = getSharedPreferences("aabbccdd", Activity.MODE_PRIVATE);
           //��ȡSharedPreferences. Editor����
        SharedPreferences. Editor editor=sp.edit();
   //��������
      editor.putString("name","String");
   editor.putString("age","String");
         //  editor.putInt("INT_KEY", 0);
         //  editor.putBoolean("BOOLEAN_KEY", true);
   //�ύ������

          editor.commit();
          super.onStop();
   // }

        
    }
}