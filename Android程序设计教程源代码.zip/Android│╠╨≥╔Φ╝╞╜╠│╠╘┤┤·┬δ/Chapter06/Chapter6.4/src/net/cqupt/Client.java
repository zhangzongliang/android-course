package net.cqupt;

import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;

public class Client {
	private static Socket socket;

	private Client() {
		try {
			socket = new Socket("192.168.1.100", 8002);
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static Socket getSocket() {
		if (socket == null)
			new Client();
		return socket;
	}

	public static void close() {
		if (socket != null)
			try {
				socket.close();
				socket = null;
			} catch (IOException e) {
				e.printStackTrace();
			}
	}

}
