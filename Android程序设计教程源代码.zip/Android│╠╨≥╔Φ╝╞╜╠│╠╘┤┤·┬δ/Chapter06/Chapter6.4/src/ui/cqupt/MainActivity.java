package ui.cqupt;

import control.cqupt.Controller;
import net.cqupt.Client;
import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class MainActivity extends Activity {
private Button play;
private MediaPlayer mediaPlayer;
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		Button insert = (Button) findViewById(R.id.m_insert);
		Button delete = (Button) findViewById(R.id.m_delete);
		Button set = (Button) findViewById(R.id.m_set);
		Button select = (Button) findViewById(R.id.m_select);
		play=(Button) findViewById(R.id.m_play);
		//mediaPlayer=MediaPlayer.create(MainActivity.this, R.raw.music01);
		//mediaPlayer.start();
		ButtonListener buttonListener = new ButtonListener();
		insert.setOnClickListener(buttonListener);
		delete.setOnClickListener(buttonListener);
		set.setOnClickListener(buttonListener);
		select.setOnClickListener(buttonListener);
		play.setOnClickListener(buttonListener);
	}

	public void onDestroy() {
		mediaPlayer.release();  
		mediaPlayer = null;
		Controller control = new Controller();
		control.exit();
		Client.close();
		super.onDestroy();
	}

	class ButtonListener implements OnClickListener {

		public void onClick(View v) {
			int id = v.getId();
			Intent intent = new Intent();
			switch (id) {
			case R.id.m_insert:
				intent.setClass(MainActivity.this, InsertActivity.class);
				MainActivity.this.startActivity(intent);
				break;
			case R.id.m_delete:
				intent.setClass(MainActivity.this, DeleteActivity.class);
				MainActivity.this.startActivity(intent);
				break;
			case R.id.m_set:
				intent.setClass(MainActivity.this, SetActivity.class);
				MainActivity.this.startActivity(intent);
				break;
			case R.id.m_select:
				intent.setClass(MainActivity.this, SelectActivity.class);
				MainActivity.this.startActivity(intent);
				break;
			case R.id.m_play:
				if("����".equals(play.getText().toString()))
				{
						mediaPlayer.start();
						play.setText("��ͣ");
					
				}else if("��ͣ".equals(play.getText().toString()))
				{
					mediaPlayer.pause();
					play.setText("����");
				}
				break;
			}
		}

	}
}