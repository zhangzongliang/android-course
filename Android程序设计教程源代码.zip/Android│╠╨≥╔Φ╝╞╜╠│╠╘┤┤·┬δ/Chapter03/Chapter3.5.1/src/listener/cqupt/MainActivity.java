package listener.cqupt;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends Activity {
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

	}

	public void click(View v) {
		Toast.makeText(MainActivity.this, "����˰�ť" + v.getId(),
				Toast.LENGTH_SHORT).show();
	}

}