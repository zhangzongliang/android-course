package your.packages.namespace;

import android.app.Activity;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;

public class MenusActivity extends Activity { 
	   private LinearLayout bc;
	   public void onCreate(Bundle savedInstanceState) { 
	      super.onCreate(savedInstanceState); 
	      setContentView(R.layout.main); 
	      bc=(LinearLayout)findViewById(R.id.lay);
	      registerForContextMenu(bc);
	   } 
	   public void onCreateContextMenu(ContextMenu menu,View v,ContextMenuInfo 										menuInfo)
	   {
		   setTitle("�˵�");
		   menu.add(0,2,0,"�˵�1");
		   menu.add(0,3,0,"�˵�2");
		   super.onCreateContextMenu(menu, v, menuInfo);
	   }
	   public boolean onContextItemSelected(MenuItem item)
	   {
		   switch(item.getItemId()){
		   case 2:
		      Toast.makeText(this, "1", Toast.LENGTH_LONG).show();
		      break;
		   case 3:
			   Toast.makeText(this, "2", Toast.LENGTH_LONG).show();
			      break;
		   }
	       return true;
	   }
	}