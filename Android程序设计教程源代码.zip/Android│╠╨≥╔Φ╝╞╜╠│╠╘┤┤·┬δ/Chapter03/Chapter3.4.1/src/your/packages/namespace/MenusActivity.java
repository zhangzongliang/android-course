package your.packages.namespace;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

public class MenusActivity extends Activity { 
   private static final int item1 = Menu.FIRST; 
   private static final int item2 = Menu.FIRST + 1;  
   public void onCreate(Bundle savedInstanceState) { 
      super.onCreate(savedInstanceState); 
      setContentView(R.layout.main); 
   }
    public boolean onCreateOptionsMenu(Menu menu) { 
        menu.add(0, item1, 0, "").setIcon(R.drawable.pic);//����ͼ�� 
        menu.add(0, item2, 0, "�ϴ�");
      return true;
   } 
   public boolean onOptionsItemSelected(MenuItem item) { 
      switch (item.getItemId()) { 
      case item1: 
        setTitle("�����˲˵�����1"); 
        break; 
      case item2: 
        setTitle("�����˲˵�����2"); 
        break; 
       } 
     return true; 
   } 
}