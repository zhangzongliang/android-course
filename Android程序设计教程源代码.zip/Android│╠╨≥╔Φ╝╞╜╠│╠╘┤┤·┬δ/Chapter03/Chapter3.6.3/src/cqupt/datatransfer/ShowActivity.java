package cqupt.datatransfer;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class ShowActivity extends Activity {
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		Intent intent = getIntent();
		Book book = (Book) intent.getSerializableExtra("book");
		String bookName = book.getBookName();
		String bookId =  book.getBookId();
		TextView textview = new TextView(this);
		textview.setText("bookName��"+bookName+"\nbookId��"+bookId);
		setContentView(textview);
	}
}
