package cqupt.datatransfer;

import java.io.Serializable;

public class Book implements Serializable{
	public String getBookName() {
		return bookName;
	}

	public String getBookId() {
		return bookId;
	}

	private String bookName = null;
	private String bookId = null;
	
	public Book(String bookName,String bookId)
	{
		this.bookId = bookId;
		this.bookName = bookName;
	}	
	
}
