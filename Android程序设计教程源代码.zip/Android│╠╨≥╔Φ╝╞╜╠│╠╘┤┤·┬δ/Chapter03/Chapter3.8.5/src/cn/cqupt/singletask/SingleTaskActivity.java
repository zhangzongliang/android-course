package cn.cqupt.singletask;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class SingleTaskActivity extends Activity{
	private TextView text;
	private Button button_stand;
	private Button button_task;

	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.singletaskactivity);
		text = (TextView) this.findViewById(R.id.text_task);
		text.setText(this.toString());
		button_stand = (Button) this.findViewById(R.id.button_stand_next);
		button_stand.setOnClickListener(new ButtonClickListener());
		button_task = (Button) this.findViewById(R.id.button_task_next);
		button_task.setOnClickListener(new ButtonClickListener_2());
	}

	// ��ť�����¼�
	private final class ButtonClickListener implements View.OnClickListener {
		public void onClick(View v) {
			LaunchStandard();
		}
	}
	
	private final class ButtonClickListener_2 implements View.OnClickListener {
		public void onClick(View v) {
			LaunchSingleTask();
		}
	}
	
	public void LaunchStandard() {
		startActivity(new Intent(this, MainActivity.class));
		text.setText(this.toString());
	}

	public void LaunchSingleTask() {
		startActivity(new Intent(this, SingleTaskActivity.class));
		text.setText(this.toString());
	}
}
