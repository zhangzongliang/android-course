package cn.cqupt.singletask;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends Activity {
    /** Called when the activity is first created. */
	private TextView text;
	private Button button_stand;
	private Button button_top;
	private Button button_task;

	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.mainactivity);
		text = (TextView) this.findViewById(R.id.text);
		text.setText(this.toString());
		button_stand = (Button) this.findViewById(R.id.button_stand);
		button_stand.setOnClickListener(new ButtonClickListener());
		button_top = (Button) this.findViewById(R.id.button_top);
		button_top.setOnClickListener(new ButtonClickListener_2());
		button_task = (Button) this.findViewById(R.id.button_task);
		button_task.setOnClickListener(new ButtonClickListener_3());
	}

	// ��ť�����¼�
	private final class ButtonClickListener implements View.OnClickListener {
		public void onClick(View v) {
			LaunchStandard();
		}
	}
	
	private final class ButtonClickListener_2 implements View.OnClickListener {
		public void onClick(View v) {
			LaunchSingleTop();
		}
	}
	
	private final class ButtonClickListener_3 implements View.OnClickListener {
		public void onClick(View v) {
			LaunchSingleTask();
		}
	}

	public void LaunchStandard() {
		startActivity(new Intent(this, MainActivity.class));
		text.setText(this.toString());
	}
	
	public void LaunchSingleTop() {
		startActivity(new Intent(this, SingleTopActivity.class));
		text.setText(this.toString());
	}
	
	public void LaunchSingleTask() {
		startActivity(new Intent(this, SingleTaskActivity.class));
		text.setText(this.toString());
	}
}