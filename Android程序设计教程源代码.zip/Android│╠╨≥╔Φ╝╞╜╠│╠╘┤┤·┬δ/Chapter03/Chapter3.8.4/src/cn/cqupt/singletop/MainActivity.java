package cn.cqupt.singletop;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends Activity {
    /** Called when the activity is first created. */
	private TextView text;
	private Button button_stand;
	private Button button_top;

	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.mainactivity);
		text = (TextView) this.findViewById(R.id.text);
		text.setText(this.toString());
		button_stand = (Button) this.findViewById(R.id.button_stand);
		button_stand.setOnClickListener(new ButtonClickListener());
		button_top = (Button) this.findViewById(R.id.button_top);
		button_top.setOnClickListener(new ButtonClickListener_2());
	}

	// ��ť�����¼�
	private final class ButtonClickListener implements View.OnClickListener {
		public void onClick(View v) {
			LaunchStandard();
		}
	}
	
	private final class ButtonClickListener_2 implements View.OnClickListener {
		public void onClick(View v) {
			LaunchSingleTop();
		}
	}

	public void LaunchStandard() {
		startActivity(new Intent(this, MainActivity.class));
		text.setText(this.toString());
	}
	
	public void LaunchSingleTop() {
		startActivity(new Intent(this, SingleTopActivity.class));
		text.setText(this.toString());
	}
}