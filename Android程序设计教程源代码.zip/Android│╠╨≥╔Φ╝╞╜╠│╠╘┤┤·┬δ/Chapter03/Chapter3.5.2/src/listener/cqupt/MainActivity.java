package listener.cqupt;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Toast;

	public class MainActivity extends Activity implements OnClickListener {
		public void onCreate(Bundle savedInstanceState) {
			super.onCreate(savedInstanceState);
			setContentView(R.layout.main);
		}
		public void onClick(View v) {
	
			if (v.getId() == R.id.button1)
				Toast.makeText(MainActivity.this, "����˰�ť"+v.getId(),
						Toast.LENGTH_SHORT).show();
		}
	}

