package your.packages.namespace;
import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;

public class MenusActivity extends Activity { 
	        public void onCreate(Bundle savedInstanceState){ 
	        super.onCreate(savedInstanceState); 
	        setContentView(R.layout.main); 
	}
public boolean onCreateOptionsMenu(Menu menu){
	    MenuInflater inflater=getMenuInflater();
		inflater.inflate(R.menu.menu1, menu);
		return true; 
	}
}