package ui.cqupt;

import control.cqupt.Controller;

import model.cqupt.Book;
import model.cqupt.BookList;

import ui.cqupt.R;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

public class SelectActivity extends Activity {

	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.select);
		Controller control = new Controller();
		BookList booklist = control.searchBook();
		CreateTable(booklist);
	}

	private void CreateTable(BookList booklist) {
		TableLayout table = (TableLayout) findViewById(R.id.SELECT_ACTIVITY_TableLayout);

		for (int i = 0; i < booklist.size(); ++i) {
			Book book = booklist.get(i);
			String id = book.getId();
			String name = book.getName();
			String price = book.getPrice();
			TableRow row = new TableRow(this);
			TextView tid = new TextView(this);
			TextView tname = new TextView(this);
			TextView tprice = new TextView(this);
			tid.setText(id);
			tname.setText(name);
			tprice.setText(price);
			row.addView(tid);
			row.addView(tname);
			row.addView(tprice);
			table.addView(row);
		}
	}
}
