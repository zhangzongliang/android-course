/** Automatically generated file. DO NOT MODIFY */
package ui.cqupt;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}