package your.packages.namespace;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.SubMenu;
import android.widget.Toast;

public class MenusActivity extends Activity {  
    public void onCreate(Bundle savedInstanceState) {  
        super.onCreate(savedInstanceState);  
       setContentView(R.layout.main);  
    }   
    public boolean onCreateOptionsMenu(Menu menu) {  
        super.onCreateOptionsMenu(menu);  
       SubMenu fileMenu=menu.addSubMenu(1, 1, 1, "File");  
       SubMenu editMenu=menu.addSubMenu(1, 2, 2, "edit");
        fileMenu.add(2, 11, 11, "New");  
        fileMenu.add(2, 12, 12, "Save");  
        fileMenu.add(2, 13, 13, "Close");  
        editMenu.add(2, 21, 21, "first");  
        editMenu.add(2, 22, 22, "second");  
        return true;  
    }  
    public boolean onOptionsItemSelected(MenuItem item) {  
       super.onOptionsItemSelected(item);  
        switch(item.getItemId()){  
            case 1:{  
               Toast.makeText(MenusActivity.this,"������"+item.getTitle(),										Toast.LENGTH_SHORT).show();  
                break;  
            }  
            case 2:{  
                Toast.makeText(MenusActivity.this, "������"+item.getTitle(),										 Toast.LENGTH_SHORT).show();  
                break;  
            }  
            case 11:{  
                Toast.makeText(MenusActivity.this, "������"+item.getTitle(),										 Toast.LENGTH_SHORT).show();  
                break;  
            }  
            case 12:{  
                Toast.makeText(MenusActivity.this, "������"+item.getTitle(), 										Toast.LENGTH_SHORT).show();  
                break;  
            }  
            case 13:{  
                Toast.makeText(MenusActivity.this, "������"+item.getTitle(), 										Toast.LENGTH_SHORT).show();  
                break;  
            }  
            case 21:{  
                Toast.makeText(MenusActivity.this, "������"+item.getTitle(),										Toast.LENGTH_SHORT).show();  
                break;  
            }  
            case 22:{  
                Toast.makeText(MenusActivity.this, "������"+item.getTitle(), 										Toast.LENGTH_SHORT).show();  
                break;  
            }  
        }  
        return true;  
    }  
}  