package db.cqupt;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import ui.cqupt.R;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class DBconnection {
	private final static String DATABASE_PATH = "/sdcard/books/";
	private final static String DATABASE_FILENAME = "book.db";

	private static Context context;

	public static void setContext(Context applicationContext) {
		context = applicationContext;
	}

	public DBconnection() {

	}

	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

	}

	public SQLiteDatabase getConnection() {

		return openDatabase();
	}

	public void close(SQLiteDatabase db,Cursor cur) {
		if(cur != null)
			cur.close();
		if (db != null)
			db.close();
	}
	
	private SQLiteDatabase openDatabase() {
		try {
			String databaseFilename = DATABASE_PATH + DATABASE_FILENAME;
			File dir = new File(DATABASE_PATH);
			if (!dir.exists()) {
				dir.mkdir();
			}
			if (!(new File(databaseFilename)).exists()) {
				InputStream is = context.getResources().openRawResource(
						R.raw.book);
				FileOutputStream fos = new FileOutputStream(databaseFilename);
				byte[] buffer = new byte[8192];
				int count = 0;
				while ((count = is.read(buffer)) > 0) {
					fos.write(buffer, 0, count);
				}

				fos.close();
				is.close();
			}
			SQLiteDatabase database = SQLiteDatabase.openOrCreateDatabase(
					databaseFilename, null);
			return database;
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}

}
