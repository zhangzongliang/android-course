package ui.cqupt;

import image.cqupt.FilesTool;

import java.util.ArrayList;

import model.cqupt.Book;
import model.cqupt.BookList;
import pull.lib.cqupt.PullToRefreshBase.OnAppendListener;
import pull.lib.cqupt.PullToRefreshBase.OnRefreshListener;
import pull.lib.cqupt.PullToRefreshListView;
import android.app.ListActivity;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import control.cqupt.Controller;

public class BookActivity extends ListActivity {

	private class RatingAdapter extends BaseAdapter {
		private Context context;
		LayoutInflater layoutInflater;
		String inflater = Context.LAYOUT_INFLATER_SERVICE;

		public RatingAdapter(Context context) {
			this.context = context;
			layoutInflater = (LayoutInflater) this.context
					.getSystemService(inflater);
		}

		public View getView(int position, View convertView, ViewGroup parent) {
			Book book = booklist.get(position);
			String id = book.getId();
			String name = book.getName();
			String price = book.getPrice();
			RelativeLayout item = (RelativeLayout) layoutInflater.inflate(R.layout.items, null);
			ImageView bookImage = (ImageView) item.findViewById(R.id.imageView_item_book);
			ImageView authorImage = (ImageView) item.findViewById(R.id.imageView_item_author);
			FilesTool fileReader = new FilesTool(id.trim());
			authorImage.setImageBitmap(fileReader.getAuthorImage());
			bookImage.setImageBitmap(fileReader.getBookImage());
			TextView nameT = (TextView) item.findViewById(R.id.name_item);
			TextView idT = (TextView) item.findViewById(R.id.id_item);
			TextView priceT = (TextView) item.findViewById(R.id.price_item);
			nameT.setText("		" + name);
			idT.setText("				书号：" + id);
			priceT.setText("		专柜价：" + price);
			return item;

		}

		public int getCount() {
			return booklist.size();
		}

		public Object getItem(int position) {
			return booklist.get(position);
		}

		public long getItemId(int position) {
			return position;
		}
	}

	protected void onListItemClick(ListView l, View v, int position, long id) {
		super.onListItemClick(l, v, position, id);
		Controller control = new Controller();
		BookList booklist = control.searchBook();
		Book book = booklist.get(position);
		Intent intent = new Intent();
		intent.setClass(this, DeleteActivity.class);
		Bundle mExtras = new Bundle();
		mExtras.putSerializable("book", book);
		intent.putExtras(mExtras);
		this.startActivity(intent);

	}

	static final int MENU_MANUAL_REFRESH = 0;
	static final int MENU_DISABLE_SCROLL = 1;

	private PullToRefreshListView mPullRefreshListView;
	private RatingAdapter raAdapter;
	ArrayList<Book> booklist = new ArrayList<Book>();
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.pull_to_refresh_list);
		mPullRefreshListView = (PullToRefreshListView) findViewById(R.id.pull_refresh_list);
		mPullRefreshListView.setOnRefreshListener(new OnRefreshListener() {
			public void onRefresh() {
				new GetDataTask().execute();
			}
		});
		mPullRefreshListView.setOnAppendListener(new OnAppendListener() {

			public void onAppend() {
				new AppendDataTask().execute();

			}
		});
		ImageView mTopImageView = (ImageView) this
				.findViewById(R.id.lv_backtotop);
		mPullRefreshListView.setBackToTopView(mTopImageView);
		raAdapter = new RatingAdapter(this);
		setListAdapter(raAdapter);
		new GetDataTask().execute();
	}

	private class GetDataTask extends AsyncTask<Void, Void, ArrayList<Book>> {
		@Override
		protected ArrayList<Book> doInBackground(Void... params) {
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
			}
			booklist.clear();
			Controller control = new Controller();
			BookList myBookList = control.searchBook();
			System.out.println(myBookList.size());
			for (int i = 0; i < 5 && i < myBookList.size(); ++i) {
				booklist.add(myBookList.get(i));
			}
			return booklist;
		}
		@Override
		protected void onPostExecute(ArrayList<Book> result) {
			mPullRefreshListView.onRefreshComplete();
			raAdapter.notifyDataSetInvalidated();
			super.onPostExecute(result);
		}
	}
	private class AppendDataTask extends AsyncTask<Void, Void, ArrayList<Book>> {
		@Override
		protected ArrayList<Book> doInBackground(Void... params) {
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
			}
			Controller control = new Controller();
			BookList myBookList = control.searchBook();
			int curNum = raAdapter.getCount();
			for (int i = curNum; i < curNum + 5 && i < myBookList.size(); ++i) {
				booklist.add(myBookList.get(i));
			}
			return booklist;
		}
		@Override
		protected void onPostExecute(ArrayList<Book> result) {
			raAdapter.notifyDataSetChanged();
			mPullRefreshListView.onRefreshComplete();
			super.onPostExecute(result);
		}
	}

}
