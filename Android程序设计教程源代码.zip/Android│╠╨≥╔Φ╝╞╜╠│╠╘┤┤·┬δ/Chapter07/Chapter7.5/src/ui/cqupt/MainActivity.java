package ui.cqupt;

import android.app.TabActivity;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.widget.TabHost;
import db.cqupt.DBconnection;

public class MainActivity extends TabActivity {

	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		DBconnection.setContext(this.getApplicationContext());
		setContentView(R.layout.main);
		Resources res = getResources(); // Resource object to get Drawables
		TabHost tabHost = getTabHost(); // The activity TabHost
		TabHost.TabSpec spec; // Reusable TabSpec for each tab
		Intent intent; // Reusable Intent for each tab

		// Create an Intent to launch an Activity for the tab (to be reused)

		intent = new Intent().setClass(this, BookActivity.class);
		spec = tabHost.newTabSpec("allBooks")
				.setIndicator("ͼ���б�", res.getDrawable(R.drawable.ic_tab_book))
				.setContent(intent);
		tabHost.addTab(spec);

		intent = new Intent().setClass(this, InsertActivity.class);
		spec = tabHost.newTabSpec("insert")
				.setIndicator("����", res.getDrawable(R.drawable.ic_tab_search))
				.setContent(intent);
		tabHost.addTab(spec);

		intent = new Intent().setClass(this, SetActivity.class);
		spec = tabHost.newTabSpec("set")
				.setIndicator("�༭", res.getDrawable(R.drawable.ic_tab_add))
				.setContent(intent);
		tabHost.addTab(spec);

		tabHost.setCurrentTab(0);
	}

}
