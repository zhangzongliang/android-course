package image.cqupt;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import db.cqupt.DBconnection;

public class FilesTool {

	private Bitmap bookBitmap = null;
	private Bitmap authorBitmap = null;


	public FilesTool(String id) {
		readImage(id);
	}

	public Bitmap getAuthorImage() {

		if (authorBitmap == null)
			readImage("delault");
		return authorBitmap;
	}

	public Bitmap getBookImage() {
		if (bookBitmap == null)
			readImage("delault");
		return bookBitmap;
	}
	private void readImage(String id) {
		DBconnection connection = new DBconnection();
		SQLiteDatabase db = connection.getConnection();
		Cursor cur = null;

		cur = db.query("image", new String[] { "bookicon", "author" },
				"id= ? ", new String[] { id }, null, null, null, null);
		int bookIndex = cur.getColumnIndex("bookicon");
		int authorIndex = cur.getColumnIndex("author");

		while (cur.moveToNext()) {
			byte[] bookicon = null;
			byte[] authoricon = null;
			bookicon = cur.getBlob(bookIndex);
			authoricon = cur.getBlob(authorIndex);
			bookBitmap = BitmapFactory.decodeByteArray(bookicon, 0,
					bookicon.length);
			authorBitmap = BitmapFactory.decodeByteArray(authoricon, 0,
					authoricon.length);
		}
		
		connection.close(db, cur);
	}
}
