package zhu.com;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class Main extends Activity {
	Intent broadcastIntent =new Intent("SELF_BROADCAST");
	class ButtonListener implements OnClickListener {
	  public void onClick(View view){
		switch (view.getId()){
			case R.id.send:
				sendBroadcast(broadcastIntent);
				break;
		}
	}
};
	public void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		Button sendBroadcast = (Button) findViewById(R.id.send);
		sendBroadcast.setOnClickListener(new ButtonListener());
	}
}