package Service.cqupt;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;
import android.util.Log;

public class Service01 extends Service {
	private MyBinder myBinder = new MyBinder();

	public void onCreate() {
		Log.d("Service", "onCreate");
		super.onCreate();
	}

	public IBinder onBind(Intent intent) {
		Log.d("Service", "onBind");
		return myBinder;
	}

	public void onDestroy() {
		Log.d("Service", "onDestroy");
		super.onDestroy();
	}

	public void onRebind(Intent intent) {
		Log.d("Service", "onRebind");
		super.onRebind(intent);
	}

	public boolean onUnbind(Intent intent) {
		Log.d("Service", "onUnbind");
		return super.onUnbind(intent);
	}
	public class MyBinder extends Binder {
		Service01 getService() {
			return Service01.this;
		}
	}

}
