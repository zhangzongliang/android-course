package Service.cqupt;

import Service.cqupt.Service01.MyBinder;
import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class MainActivity extends Activity {
	private Button bindServiceBtn;
	private Button stopServiceBtn;
	private Service01 mService;
	private ServiceConnection serviceConnection = new ServiceConnection(){
		public void onServiceDisconnected(ComponentName name){
			Log.d("Service", "Service Failed");
		}
		public void onServiceConnected(ComponentName name, IBinder service){
			MyBinder binder = (Service01.MyBinder) service;
            mService = binder.getService();
			Log.d("Service", "Service Connected");
		}
	};

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        bindServiceBtn = (Button) findViewById(R.id.bindService);
        bindServiceBtn.setOnClickListener(new OnstartServiceListener());
        stopServiceBtn = (Button) findViewById(R.id.stopService);
        stopServiceBtn.setOnClickListener(new OnstopServiceListener());
    }
    private class OnstartServiceListener implements OnClickListener
    {
		public void onClick(View arg0) {
			Intent intent = new Intent();
			intent.setClass(MainActivity.this, Service01.class);
			bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE);
		}	
    }
	private class OnstopServiceListener implements OnClickListener {
		public void onClick(View arg0) {
			Intent intent = new Intent();
			intent.setClass(MainActivity.this, Service01.class);
			unbindService(serviceConnection);
		}
	}
}