package control.cqupt;

import java.io.IOException;
import java.io.OutputStream;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import net.cqupt.Client;
import net.cqupt.ClientThread;
import util.cqupt.Packager;
import util.cqupt.Parser;
import model.cqupt.Book;
import model.cqupt.Response;

public class Controller {
	private Handler handler;

	public Controller() {

	}

	public Controller(Handler handler) {
		this.handler = handler;
	}

	public void addBook(String id,String name,String price) {
		Packager packager = new Packager();
		String message = packager.addPackage(id,name,price);
		new ClientThread(this, message).start();

	}

	public void searchBook() {
		Packager packager = new Packager();
		String message = packager.searchPackage();
		new ClientThread(this, message).start();

	}

	public void deleteBook(String name) {
		Packager packager = new Packager();
		String message=packager.deletePackage(name);
		new ClientThread(this, message).start();
	}

	public void setBook(String id,String name,String price) {
		Packager packager = new Packager();
		String message = packager.setPackage(id,name,price);
		new ClientThread(this, message).start();

	}

	public void doResponse(String message) {
		Parser parser=new Parser();
		Response response=parser.parserResponse(message);
		String operate = response.getOperate();
		String result = response.getResult();
		Message msg = new Message();
		Bundle bundle = new Bundle();// �������
		//����һ��������չ�Ժ�
		if (operate.equals("insert")) {
			bundle.putString("result", result);
			msg.setData(bundle);
			handler.sendMessage(msg);
		} else if (operate.equals("delete")) {
			bundle.putString("result", result);
			msg.setData(bundle);
			handler.sendMessage(msg);
		}else if (operate.equals("set")) {
			bundle.putString("result", result);
			msg.setData(bundle);
			handler.sendMessage(msg);
		}else if (operate.equals("select")) {
			bundle.putString("result", result);
			msg.setData(bundle);
			handler.sendMessage(msg);
		}
	}
	
	public void doUpdate(String str)
	{
		Parser parser=new Parser();
		Book book=parser.parseBook(str);
		Message msg = new Message();
		Bundle bundle = new Bundle();// �������
		bundle.putString("content", book.toString());
		msg.setData(bundle);
		handler.sendMessage(msg);
	}

	public void exit() {
		Packager packager = new Packager();
		String message = packager.exitPackage();
		OutputStream out = null;
		try {
			out = Client.getSocket().getOutputStream();
			out.write(message.getBytes("GBK"));
			out.flush();
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			Client.close();
		}

	}
}
