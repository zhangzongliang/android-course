package net.cqupt;

import java.io.IOException;
import java.io.InputStream;
import java.net.Socket;
import control.cqupt.Controller;
import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.Handler;
import android.os.IBinder;

public class UpDateService extends Service {

	private MyBinder myBinder = new MyBinder();

	public IBinder onBind(Intent intent) {
		return myBinder;
	}

	public boolean onUnbind(Intent intent) {
		return super.onUnbind(intent);
	}

	public void update(Handler handler) {
		new ServiceThread(handler).start();
	}

	public class ServiceThread extends Thread {
		private Handler handler;

		public ServiceThread(Handler handler) {
			this.handler = handler;
		}

		public void run() {
			try {
				Socket socket = new Socket("172.22.146.112", 8003);
				while (true) {
					InputStream in = socket.getInputStream();
					byte[] buffer = new byte[1024];
					int index = in.read(buffer);
					String message = new String(buffer, 0, index, "GBK");
					Controller controller = new Controller(handler);
					controller.doUpdate(message);
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	public class MyBinder extends Binder {
		public UpDateService getService() {
			return UpDateService.this;
		}
	}
}
