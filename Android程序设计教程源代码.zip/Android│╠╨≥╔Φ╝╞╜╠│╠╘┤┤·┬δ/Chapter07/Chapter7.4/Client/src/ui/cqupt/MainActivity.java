package ui.cqupt;

import control.cqupt.Controller;
import net.cqupt.Client;
import net.cqupt.UpDateService;
import net.cqupt.UpDateService.MyBinder;
import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class MainActivity extends Activity {
	private UpDateService upDateService;

	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		Button insert = (Button) findViewById(R.id.m_insert);
		Button delete = (Button) findViewById(R.id.m_delete);
		Button set = (Button) findViewById(R.id.m_set);
		Button select = (Button) findViewById(R.id.m_select);
		ButtonListener buttonListener = new ButtonListener();
		insert.setOnClickListener(buttonListener);
		delete.setOnClickListener(buttonListener);
		set.setOnClickListener(buttonListener);
		select.setOnClickListener(buttonListener);
		Intent bindIntent = new Intent(this, UpDateService.class);
		this.getApplicationContext().bindService(bindIntent, serviceConnection,
				Context.BIND_AUTO_CREATE);
	}

	public void onDestroy() {
		this.getApplicationContext().unbindService(serviceConnection);
		Controller control = new Controller();
		control.exit();
		Client.close();
		super.onDestroy();
	}

	private Handler handler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			Bundle b = msg.getData();
			String content = b.getString("content");
			buildDialog(content);
		}
	};

	private void buildDialog(String result) {
		Builder builder = new Builder(this);
		builder.setTitle("����ͼ��" + "\n" + result);
		builder.setNegativeButton("��ѯ", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int whichButton) {
				Intent intent = new Intent();
				intent.setClass(MainActivity.this, SelectActivity.class);
				MainActivity.this.startActivity(intent);
			}

		});
		builder.setPositiveButton("ȡ��", null);
		builder.show();
	}

	private ServiceConnection serviceConnection = new ServiceConnection() {

		@Override
		public void onServiceConnected(ComponentName name, IBinder service) {
			MyBinder myBinder = (UpDateService.MyBinder) service;
			upDateService = myBinder.getService();
			upDateService.update(handler);
		}

		@Override
		public void onServiceDisconnected(ComponentName name) {
			upDateService = null;
		}

	};

	class ButtonListener implements OnClickListener {

		public void onClick(View v) {
			int id = v.getId();
			Intent intent = new Intent();
			switch (id) {
			case R.id.m_insert:
				intent.setClass(MainActivity.this, InsertActivity.class);
				MainActivity.this.startActivity(intent);
				break;
			case R.id.m_delete:
				intent.setClass(MainActivity.this, DeleteActivity.class);
				MainActivity.this.startActivity(intent);
				break;
			case R.id.m_set:
				intent.setClass(MainActivity.this, SetActivity.class);
				MainActivity.this.startActivity(intent);
				break;
			case R.id.m_select:
				intent.setClass(MainActivity.this, SelectActivity.class);
				MainActivity.this.startActivity(intent);
				break;
			}
		}

	}
}