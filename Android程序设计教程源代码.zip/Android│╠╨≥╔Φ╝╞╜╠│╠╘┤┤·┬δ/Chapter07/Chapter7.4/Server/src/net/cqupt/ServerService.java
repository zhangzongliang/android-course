package net.cqupt;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;

public class ServerService extends Thread {
	private ServerSocket serverscoket;
	private HashMap<String, Socket> socketPool = new HashMap<String, Socket>();

	public void run() {
		try {
			serverscoket = new ServerSocket(8003);
			while (!ServerService.interrupted()) {
				Socket socket = serverscoket.accept();
				String name = socket.getLocalAddress().getHostAddress() + "::"
						+ socket.getPort();
				socketPool.put(name, socket);
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			close();
		}

	}
	

    public HashMap<String, Socket> getSocketPool()
    {
    	return socketPool; 
    }

	public void deleteThread(String name) {
		Socket socket = socketPool.get(name);
		try {
			socket.close();
			socketPool.remove(name);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}

	public void close() {
		if (serverscoket != null) {
			try {
				serverscoket.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}
