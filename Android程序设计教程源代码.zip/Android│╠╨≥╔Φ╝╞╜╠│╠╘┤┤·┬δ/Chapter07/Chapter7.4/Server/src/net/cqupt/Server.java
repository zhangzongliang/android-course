package net.cqupt;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import control.cqupt.Controller;

public class Server extends Thread {
	private ServerSocket serverscoket;
	private HashMap<String, ServerThread> threadPool = new HashMap<String, ServerThread>();
	private Controller controller;

	public Server() {
		controller = new Controller();
	}

	public void run() {
		try {
			serverscoket = new ServerSocket(8002);
			while (!Server.interrupted()) {
				Socket socket = serverscoket.accept();
				String name = socket.getLocalAddress().getHostAddress() + "::"
						+ socket.getPort();
				ServerThread st = new ServerThread(name, socket, this);
				threadPool.put(name, st);
				st.start();
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			close();
		}

	}
	

    public HashMap<String, ServerThread> getThreadPool()
    {
    	return threadPool; 
    }

	public void deleteThread(String name) {
		ServerThread thread = threadPool.get(name);
		thread.interrupt();
		threadPool.remove(name);
	}

	public Controller getController() {
		return controller;
	}

	public void close() {
		if (serverscoket != null) {
			try {
				serverscoket.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}
