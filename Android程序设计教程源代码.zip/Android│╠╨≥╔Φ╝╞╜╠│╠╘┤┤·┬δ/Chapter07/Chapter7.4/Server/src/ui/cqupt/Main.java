package ui.cqupt;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JButton;

import control.cqupt.Controller;
import net.cqupt.Server;
import net.cqupt.ServerService;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.OutputStream;
import java.net.Socket;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class Main extends JFrame implements ActionListener{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField idField;
	private JTextField nameField;
	private JTextField priceField;
	Server server;
	ServerService serverService;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Main frame = new Main();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Main() {
		server=new Server();
		server.start();
		serverService=new ServerService();
		serverService.start();
		setTitle("server");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		idField = new JTextField();
		idField.setColumns(10);
		
		JLabel id = new JLabel("ͼ����");
		
		JLabel name = new JLabel("ͼ������");
		
		nameField = new JTextField();
		nameField.setColumns(10);
		
		JLabel price = new JLabel("ͼ��۸�");
		
		priceField = new JTextField();
		priceField.setColumns(10);
		
		JButton sendbutton = new JButton("����");
		sendbutton.addActionListener(this);
		
		JLabel title = new JLabel("����ͼ��");
		title.setFont(new Font("����", Font.BOLD, 20));
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(111)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false)
								.addGroup(gl_contentPane.createSequentialGroup()
									.addComponent(price)
									.addPreferredGap(ComponentPlacement.UNRELATED)
									.addComponent(priceField))
								.addGroup(gl_contentPane.createSequentialGroup()
									.addComponent(name)
									.addPreferredGap(ComponentPlacement.UNRELATED)
									.addComponent(nameField))
								.addGroup(gl_contentPane.createSequentialGroup()
									.addComponent(id)
									.addPreferredGap(ComponentPlacement.UNRELATED)
									.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false)
										.addComponent(idField)
										.addComponent(title, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(161)
							.addComponent(sendbutton)))
					.addContainerGap(162, Short.MAX_VALUE))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(22)
					.addComponent(title)
					.addGap(39)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(idField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(id))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(name)
						.addComponent(nameField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(price)
						.addComponent(priceField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addComponent(sendbutton)
					.addContainerGap(47, Short.MAX_VALUE))
		);
		contentPane.setLayout(gl_contentPane);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public void actionPerformed(ActionEvent e){
		String bid=idField.getText();
		String bname=nameField.getText();
		String bprice=priceField.getText();
		idField.setText("");
		nameField.setText("");
		priceField.setText("");
		Controller controller=new Controller();
		String mes=controller.upDate(bid, bname, bprice);
		HashMap<String, Socket> socketPool =serverService.getSocketPool();
		Set entry = socketPool.entrySet();
		Iterator iter = entry.iterator();
		OutputStream out=null;
		while(iter.hasNext())
		{
			Map.Entry<String, Socket> name= (Entry<String, Socket>) iter.next();
			Socket socket=name.getValue();
			try {
				out=socket.getOutputStream();
				out.write(mes.getBytes("GBK"));
				out.flush();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
	}
}
