package service.cqupt;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;

public class Service01 extends Service{

	public IBinder onBind(Intent intent) {
		Log.d("Service", "onBind");
		return null;
	}
	public void onCreate() {
		Log.d("Service", "onCreate");
		super.onCreate();
	}
	public int onStartCommand(Intent intent, int flags, int startId) {
		Log.d("Service", "onStartCommand");
		return super.onStartCommand(intent, flags, startId);
	}
	public void onDestroy() {
		Log.d("Service", "onDestroy");
		super.onDestroy();
	}
}
