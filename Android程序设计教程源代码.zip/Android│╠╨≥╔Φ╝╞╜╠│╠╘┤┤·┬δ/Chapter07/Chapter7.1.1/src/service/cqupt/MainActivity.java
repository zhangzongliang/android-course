package service.cqupt;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class MainActivity extends Activity {
	private Button startServiceBtn;
	private Button stopServiceBtn;
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        startServiceBtn = (Button) findViewById(R.id.startService);
        startServiceBtn.setOnClickListener(new OnstartServiceListener());
        stopServiceBtn = (Button) findViewById(R.id.stopService);
        stopServiceBtn.setOnClickListener(new OnstopServiceListener());
        System.out.println("MainActivity onCreate");
    }
    private class OnstartServiceListener implements OnClickListener
    {
		public void onClick(View arg0) {
			Intent intent = new Intent();
			intent.setClass(MainActivity.this, Service01.class);
			startService(intent);
		}	
    }
	private class OnstopServiceListener implements OnClickListener {
		public void onClick(View arg0) {
			Intent intent = new Intent();
			intent.setClass(MainActivity.this, Service01.class);
			stopService(intent);
		}
	}
}