package net.cqupt;

import java.io.IOException;
import control.cqupt.Controller;
import javax.servlet.ServletInputStream;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Server extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void doPost(HttpServletRequest req, HttpServletResponse resp) {
		ServletInputStream in;
		ServletOutputStream out;
		try {
			in = req.getInputStream();
			out = resp.getOutputStream();
			int len = req.getContentLength();
			byte[] buffer = new byte[len];
			int index = in.read(buffer);
			String message = new String(buffer, 0, index, "GBK");
			Controller controller = new Controller();
			String response = controller.doResponse(message);
			out.write(response.getBytes("GBK"));
			in.close();
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}