package net.cqupt;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import control.cqupt.Controller;

public class ClientThread extends Thread {
	private InputStream in;
	private OutputStream out;
	private static final int SIZE = 1024;
	private String mes;
	private Controller controller;

	public ClientThread(Controller controller, String mes) {
		this.controller = controller;
		this.mes = mes;

	}

	public void run() {

		String urlStr = "http://192.168.1.100:8080/FiveHttpServer/server";
		URL url;
		try {
			url = new URL(urlStr);
			HttpURLConnection connection = (HttpURLConnection) url
					.openConnection();
			connection.setDoOutput(true);
			connection.setRequestMethod("POST");
			out = connection.getOutputStream();
			send();
			in = connection.getInputStream();
			byte[] buffer = new byte[SIZE];
			int index = in.read(buffer);
			String message = new String(buffer, 0, index, "GBK");
			controller.doResponse(message);
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public void send() {
		try {
			out.write(mes.getBytes("GBK"));
			out.flush();
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
