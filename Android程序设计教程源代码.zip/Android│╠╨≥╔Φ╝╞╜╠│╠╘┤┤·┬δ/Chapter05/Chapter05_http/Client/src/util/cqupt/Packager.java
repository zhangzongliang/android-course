package util.cqupt;

public class Packager {
	public String addPackage(String id, String name, String price) {
		StringBuffer mes = new StringBuffer("");
		mes.append("operate:insert" + "\n");
		String content = BookPackage(id, name, price);
		mes.append("content:" + content + "\n");
		return mes.toString();
	}

	public String searchPackage() {
		StringBuffer mes = new StringBuffer("");
		mes.append("operate:select" + "\n");
		mes.append("content:" + "\n");
		return mes.toString();

	}

	public String deletePackage(String name) {
		StringBuffer mes = new StringBuffer("");
		mes.append("operate:delete" + "\n");
		mes.append("content:" + name + "\n");
		return mes.toString();
	}

	public String setPackage(String id, String name, String price) {
		StringBuffer mes = new StringBuffer("");
		mes.append("operate:set" + "\n");
		String content = BookPackage(id, name, price);
		mes.append("content:" + content + "\n");
		return mes.toString();
	}

	public String exitPackage() {
		StringBuffer mes = new StringBuffer("");
		mes.append("operate:exit" + "\n");
		mes.append("content:" + "\n");
		return mes.toString();
	}

	public String BookPackage(String id, String name, String price) {
		StringBuffer str = new StringBuffer("");
		str.append(id + "#" + name + "#" + price);
		return str.toString();
	}

}
