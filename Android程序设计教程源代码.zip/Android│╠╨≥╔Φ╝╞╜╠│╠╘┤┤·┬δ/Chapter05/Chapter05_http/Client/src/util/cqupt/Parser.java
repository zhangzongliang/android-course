package util.cqupt;

import model.cqupt.Book;
import model.cqupt.BookList;
import model.cqupt.Response;

public class Parser {

	public Response parserResponse(String mes) {
		String[] message = mes.toString().split("\n");
		int length = message.length;
		String operate = message[0].substring(8, message[0].length());
		String result = message[length - 1].substring(7,
				message[length - 1].length());
		Response response = Response.getResponse();
		response.setOperate(operate);
		response.setResult(result);
		BookList booklist = new BookList();
		for (int i = 1; i < message.length - 1; ++i) {
			String str = null;
			if (i == 1) {
				str = message[1].substring(8, message[1].length());
			} else {
				str = message[i];
			}
			Book book = parseBook(str);
			booklist.add(book);
		}
		response.setBooklist(booklist);
		return response;
	}

	public Book parseBook(String str) {
		String[] mes = str.split("#");
		String id = mes[0];
		String name = mes[1];
		String price = mes[2];
		return new Book(id, name, price);
	}

}
