package model.cqupt;

import java.util.ArrayList;

public class BookList extends ArrayList<Book> {

	private static final long serialVersionUID = 1L;

}
