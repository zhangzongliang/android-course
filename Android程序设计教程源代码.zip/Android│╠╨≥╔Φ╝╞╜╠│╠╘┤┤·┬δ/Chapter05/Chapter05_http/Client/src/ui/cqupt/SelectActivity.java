package ui.cqupt;

import control.cqupt.Controller;

import model.cqupt.Book;
import model.cqupt.BookList;
import model.cqupt.Response;

import ui.cqupt.R;

import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

public class SelectActivity extends Activity {

	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.select);
		Controller control = new Controller(handler);
		control.searchBook();
	}

	private Handler handler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			Bundle b = msg.getData();
			String result = b.getString("result");
			buildDialog(result);
			Response response = Response.getResponse();
			BookList booklist = response.getBookList();
			CreateTable(booklist);
		}
	};

	private void CreateTable(BookList booklist) {
		TableLayout table = (TableLayout) findViewById(R.id.SELECT_ACTIVITY_TableLayout);
		for (int i = 0; i < booklist.size(); ++i) {
			Book book = booklist.get(i);
			String id = book.getId();
			String name = book.getName();
			String price = book.getPrice();
			TableRow row = new TableRow(this);
			TextView tid = new TextView(this);
			TextView tname = new TextView(this);
			TextView tprice = new TextView(this);
			tid.setText(id);
			tname.setText(name);
			tprice.setText(price);
			row.addView(tid);
			row.addView(tname);
			row.addView(tprice);
			table.addView(row);
		}
	}

	private void buildDialog(String result) {
		Builder builder = new Builder(SelectActivity.this);
		builder.setTitle(result);
		builder.setPositiveButton("ȷ��", null);
		builder.show();
	}

}
