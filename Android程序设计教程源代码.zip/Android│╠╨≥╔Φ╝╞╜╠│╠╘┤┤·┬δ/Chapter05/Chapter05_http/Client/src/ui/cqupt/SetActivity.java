package ui.cqupt;

import control.cqupt.Controller;
import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

public class SetActivity extends Activity {
	private EditText name;
	private EditText id;
	private EditText price;

	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.set);
		name = (EditText) findViewById(R.id.sname);
		id = (EditText) findViewById(R.id.sid);
		price = (EditText) findViewById(R.id.sprice);
		Button set = (Button) findViewById(R.id.s_set);
		set.setOnClickListener(new ButtonListener());
	}

	private Handler handler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			Bundle b = msg.getData();
			String result = b.getString("result");
			buildDialog(result);
		}
	};

	class ButtonListener implements OnClickListener {

		public void onClick(View v) {
			String bookname = name.getText().toString();
			String bookid = id.getText().toString();
			String bookprice = price.getText().toString();

			Controller control = new Controller(handler);
			if (bookname.equals("") || bookid.equals("")
					|| bookprice.equals("")) {
				new Builder(SetActivity.this).setMessage("ͼ����Ϣ����Ϊ��").show();
			} else {

				control.setBook(bookid, bookname, bookprice);
				id.setText("");
				name.setText("");
				price.setText("");
			}
		}
	}

	private void buildDialog(String result) {
		Builder builder = new Builder(SetActivity.this);
		builder.setTitle(result);
		builder.setNegativeButton("������ҳ",
				new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int whichButton) {
						finish();
					}

				});
		builder.setPositiveButton("�����޸�", null);
		builder.show();
	}
}
