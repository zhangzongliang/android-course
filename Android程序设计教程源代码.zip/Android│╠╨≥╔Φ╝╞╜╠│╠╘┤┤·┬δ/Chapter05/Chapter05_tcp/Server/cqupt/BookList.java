package model.cqupt;

import java.util.ArrayList;

import db.cqupt.DBconnection;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class BookList extends ArrayList<Book> {

	private static final long serialVersionUID = 1L;

	private static BookList booklist = null;

	private BookList() {

	}

	/**
	 * ����id
	 * 
	 * @param bookid
	 * @return
	 */
	public static boolean hasId(String bookid) {
		if (booklist == null)
			booklist = new BookList();
		for (int i = 0; i < booklist.size(); ++i) {
			Book book = booklist.get(i);
			String id = book.getId();
			if (id.equals(bookid)) {
				return true;
			}
		}
		return false;
	}

	/**
	 * �õ�ͼ��λ��
	 * 
	 * @param bookid
	 * @return
	 */
	public static int getIndex(String bookid) {
		if (booklist == null)
			booklist = new BookList();
		int i = 0;
		for (; i < booklist.size(); ++i) {
			Book book = booklist.get(i);
			String id = book.getId();
			if (id.equals(bookid)) {
				break;
			}
		}
		return i;
	}

	/**
	 * ��������
	 * 
	 * @param name
	 * @return
	 */
	public static boolean hasName(String name) {
		if (booklist == null)
			booklist = new BookList();
		for (int i = 0; i < booklist.size(); ++i) {
			Book book2 = booklist.get(i);
			if (book2.getName().equals(name)) {
				booklist.remove(i);
				return true;
			}
		}
		return false;
	}

	public static boolean insert(Book book) {

		if (hasId(book.getId())) {
			return false;
		} else {
			booklist.add(book);
			String id = book.getId();
			String name = book.getName();
			String price = book.getPrice();
			DBconnection connection = new DBconnection();
			SQLiteDatabase db = connection.getConnection();
			String sql = "INSERT INTO book(id,name,price)" + "VALUES('" + id
					+ "','" + name + "','" + price + "')";
			db.execSQL(sql);
			db.close();
			return true;
		}
	}

	public static boolean delete(String name) {
		if (hasName(name)) {
			DBconnection connection = new DBconnection();
			SQLiteDatabase db = connection.getConnection();
			String sql = "DELETE FROM book WHERE name='" + name + "'";
			db.execSQL(sql);
			return true;
		} else {
			return false;
		}
	}

	public static boolean set(Book book) {
		if (hasId(book.getId())) {
			String id = book.getId();
			String name = book.getName();
			String price = book.getPrice();
			int index = getIndex(id);
			booklist.set(index, book);
			DBconnection connection = new DBconnection();
			SQLiteDatabase db = connection.getConnection();
			String sql = "UPDATE book SET name='" + name + "'," + "price='"
					+ price + "' WHERE id='" + id + "'";
			db.execSQL(sql);
			return true;
		} else {
			return false;
		}
	}

	public static BookList getBookList() {
		if (booklist == null) {
			booklist = new BookList();
			DBconnection connection = new DBconnection();
			SQLiteDatabase db = connection.getConnection();
			Cursor cur = db.query("book", null, null, null, null, null, null);
			while (cur.moveToNext()) {
				int idNum = cur.getColumnIndex("id");
				int nameNum = cur.getColumnIndex("name");
				int priceNum = cur.getColumnIndex("price");
				String id = cur.getString(idNum);
				String name = cur.getString(nameNum);
				String price = cur.getString(priceNum);
				Book book = new Book(id, name, price);
				booklist.add(book);
				cur.moveToNext();
			}
			connection.close(db);
		}
		return booklist;

	}

}
