package net.cqupt;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;

import control.cqupt.Controller;

public class ClientThread extends Thread {
	private InputStream in = null;
	private OutputStream out = null;
	private static final int SIZE = 1024;
	private String mes;
	private Controller controller;

	public ClientThread(Controller controller, String mes) {
		Socket socket = Client.getSocket();
		this.controller = controller;
		this.mes = mes;
		try {
			out = socket.getOutputStream();
			in = socket.getInputStream();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void run() {

		try {
			send();
			byte[] buffer = new byte[SIZE];
			int index = in.read(buffer);
			String message = new String(buffer, 0, index, "GBK");
			controller.doResponse(message);
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public void send() {
		try {
			out.write(mes.getBytes("GBK"));
			out.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
